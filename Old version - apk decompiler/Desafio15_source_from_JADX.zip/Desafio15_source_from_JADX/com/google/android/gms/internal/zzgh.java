package com.google.android.gms.internal;

import android.support.annotation.Nullable;

@zzme
public class zzgh {
    @Nullable
    public static zzgj zza(@Nullable zzgl com_google_android_gms_internal_zzgl, long j) {
        return com_google_android_gms_internal_zzgl == null ? null : com_google_android_gms_internal_zzgl.zzc(j);
    }

    public static boolean zza(@Nullable zzgl com_google_android_gms_internal_zzgl, @Nullable zzgj com_google_android_gms_internal_zzgj, long j, String... strArr) {
        return (com_google_android_gms_internal_zzgl == null || com_google_android_gms_internal_zzgj == null) ? false : com_google_android_gms_internal_zzgl.zza(com_google_android_gms_internal_zzgj, j, strArr);
    }

    public static boolean zza(@Nullable zzgl com_google_android_gms_internal_zzgl, @Nullable zzgj com_google_android_gms_internal_zzgj, String... strArr) {
        return (com_google_android_gms_internal_zzgl == null || com_google_android_gms_internal_zzgj == null) ? false : com_google_android_gms_internal_zzgl.zza(com_google_android_gms_internal_zzgj, strArr);
    }

    @Nullable
    public static zzgj zzb(@Nullable zzgl com_google_android_gms_internal_zzgl) {
        return com_google_android_gms_internal_zzgl == null ? null : com_google_android_gms_internal_zzgl.zzfB();
    }
}
