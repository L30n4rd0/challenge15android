package com.google.android.gms.internal;

public class zzba extends Exception {
    public zzba(Throwable th) {
        super(th);
    }
}
