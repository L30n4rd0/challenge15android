package com.google.android.gms.internal;

import android.content.Context;
import java.util.concurrent.Future;

public interface zznm {

    public static class zza {
        public final int zzVf;
        public final long zzVg;
        public final long zzVh;
    }

    Future<zza> zzB(Context context);
}
