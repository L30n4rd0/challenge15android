package com.google.android.gms.internal;

public interface zzoh {
    void onRewardedVideoAdClosed();

    void onRewardedVideoAdLeftApplication();

    void onRewardedVideoAdOpened();

    void onRewardedVideoStarted();

    void zzc(zzoo com_google_android_gms_internal_zzoo);

    void zzjG();
}
