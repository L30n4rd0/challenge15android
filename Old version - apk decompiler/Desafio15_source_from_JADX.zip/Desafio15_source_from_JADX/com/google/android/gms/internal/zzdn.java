package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@zzme
public class zzdn {
    private final Object zzyD;
    private Map<Object, Object> zzyE;
    private ArrayList<Object> zzyF;

    public zzdn() {
        this.zzyD = new Object();
        this.zzyE = new HashMap();
        this.zzyF = new ArrayList();
    }
}
