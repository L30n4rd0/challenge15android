package com.google.android.gms.internal;

public interface zzkx {
    void zza(int i, int i2, int i3, int i4);

    void zzcb();
}
