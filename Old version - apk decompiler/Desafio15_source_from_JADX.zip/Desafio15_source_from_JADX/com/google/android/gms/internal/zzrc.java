package com.google.android.gms.internal;

import android.annotation.TargetApi;

@zzme
@TargetApi(17)
public class zzrc {
    private final zzqw zzIs;

    public zzrc(zzqw com_google_android_gms_internal_zzqw) {
        this.zzIs = com_google_android_gms_internal_zzqw;
    }
}
