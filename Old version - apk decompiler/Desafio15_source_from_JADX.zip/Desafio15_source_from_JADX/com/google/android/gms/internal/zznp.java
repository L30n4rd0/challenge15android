package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.zznm.zza;
import java.util.concurrent.Future;

@zzme
public final class zznp implements zznm {
    public Future<zza> zzB(Context context) {
        return new zzqk(null);
    }
}
