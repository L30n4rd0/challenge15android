package com.google.android.gms.internal;

public interface zzcu {
    void zza(zzct com_google_android_gms_internal_zzct);
}
