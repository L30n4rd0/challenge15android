package com.google.android.gms.internal;

import java.util.Map;

@zzme
public interface zzid {
    void zza(zzqw com_google_android_gms_internal_zzqw, Map<String, String> map);
}
