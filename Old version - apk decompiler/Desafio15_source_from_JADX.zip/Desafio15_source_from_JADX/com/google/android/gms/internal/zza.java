package com.google.android.gms.internal;

public class zza extends zzs {
    public zza(zzj com_google_android_gms_internal_zzj) {
        super(com_google_android_gms_internal_zzj);
    }

    public String getMessage() {
        return super.getMessage();
    }
}
