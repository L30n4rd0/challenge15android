package com.google.android.gms.internal;

import android.content.Context;
import org.json.JSONObject;

@zzme
public class zzdw implements zzdu {
    public JSONObject zzj(Context context) {
        return new JSONObject();
    }
}
