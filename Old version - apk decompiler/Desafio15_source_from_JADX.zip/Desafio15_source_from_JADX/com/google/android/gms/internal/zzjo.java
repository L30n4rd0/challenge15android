package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.location.Location;

@zzme
public final class zzjo implements zzjn {
    public zzqm<Location> zza(ApplicationInfo applicationInfo) {
        return new zzqk(null);
    }
}
