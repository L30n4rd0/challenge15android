package com.google.android.gms.internal;

import java.util.ArrayList;

public interface zzif {
    void zza(String str, ArrayList<String> arrayList);
}
