package com.google.android.gms.internal;

import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;

@zzme
public class zzqr {
    public void zza(View view, OnGlobalLayoutListener onGlobalLayoutListener) {
        new zzqs(view, onGlobalLayoutListener).zzln();
    }

    public void zza(View view, OnScrollChangedListener onScrollChangedListener) {
        new zzqt(view, onScrollChangedListener).zzln();
    }
}
