package com.google.android.gms.internal;

import android.content.Context;

@zzme
public class zznn extends zznk {
    public void zza(Context context, zzne com_google_android_gms_internal_zzne, zzqh com_google_android_gms_internal_zzqh) {
        zze(com_google_android_gms_internal_zzne);
    }
}
