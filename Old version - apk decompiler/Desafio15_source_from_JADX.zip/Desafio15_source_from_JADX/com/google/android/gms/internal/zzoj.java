package com.google.android.gms.internal;

public interface zzoj {
    void zza(String str, int i);

    void zzaO(String str);
}
