package com.google.android.gms.internal;

@zzme
public class zzjm {
    private final Object zzrJ;

    public zzjm() {
        this.zzrJ = new Object();
    }
}
