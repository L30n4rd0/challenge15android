package com.google.android.gms.internal;

import android.content.Context;

@zzme
public abstract class zznk {
    public abstract void zza(Context context, zzne com_google_android_gms_internal_zzne, zzqh com_google_android_gms_internal_zzqh);

    protected void zze(zzne com_google_android_gms_internal_zzne) {
        if (com_google_android_gms_internal_zzne.zzjv() != null) {
            com_google_android_gms_internal_zzne.zzjv().release();
        }
    }
}
