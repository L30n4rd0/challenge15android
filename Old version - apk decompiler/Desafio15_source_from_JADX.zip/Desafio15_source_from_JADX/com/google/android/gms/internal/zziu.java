package com.google.android.gms.internal;

public interface zziu {
    zzis zza(zzqw com_google_android_gms_internal_zzqw, int i, String str);
}
