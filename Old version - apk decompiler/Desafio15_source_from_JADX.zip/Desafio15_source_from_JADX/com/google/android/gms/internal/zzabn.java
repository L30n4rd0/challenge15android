package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.api.Api.zzb;

public final class zzabn {
    public final zzabm<zzb, ?> zzazG;
    public final zzabz<zzb, ?> zzazH;

    public zzabn(@NonNull zzabm<zzb, ?> com_google_android_gms_internal_zzabm_com_google_android_gms_common_api_Api_zzb__, @NonNull zzabz<zzb, ?> com_google_android_gms_internal_zzabz_com_google_android_gms_common_api_Api_zzb__) {
        this.zzazG = com_google_android_gms_internal_zzabm_com_google_android_gms_common_api_Api_zzb__;
        this.zzazH = com_google_android_gms_internal_zzabz_com_google_android_gms_common_api_Api_zzb__;
    }
}
