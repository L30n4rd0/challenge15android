package com.google.android.gms.internal;

@zzme
public class zzia implements zziu {
    public zzis zza(zzqw com_google_android_gms_internal_zzqw, int i, String str) {
        return new zziv(com_google_android_gms_internal_zzqw);
    }
}
