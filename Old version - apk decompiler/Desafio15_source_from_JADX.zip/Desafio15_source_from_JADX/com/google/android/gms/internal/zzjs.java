package com.google.android.gms.internal;

public interface zzjs {
    void zzbP();

    void zzbQ();

    void zzbR();

    void zzbS();

    void zzbT();

    void zzbU();
}
