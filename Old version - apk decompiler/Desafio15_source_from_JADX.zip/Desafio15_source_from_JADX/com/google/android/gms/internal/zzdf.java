package com.google.android.gms.internal;

@zzme
public class zzdf {
    private final float zzyh;
    private final float zzyi;
    private final float zzyj;
    private final float zzyk;
    private final int zzyl;

    public zzdf(float f, float f2, float f3, float f4, int i) {
        this.zzyh = f;
        this.zzyi = f2;
        this.zzyj = f + f3;
        this.zzyk = f2 + f4;
        this.zzyl = i;
    }

    float zzeo() {
        return this.zzyh;
    }

    float zzep() {
        return this.zzyi;
    }

    float zzeq() {
        return this.zzyj;
    }

    float zzer() {
        return this.zzyk;
    }

    int zzes() {
        return this.zzyl;
    }
}
